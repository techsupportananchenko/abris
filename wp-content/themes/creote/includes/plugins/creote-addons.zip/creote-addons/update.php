<?php
 // update
if(!defined('ABSPATH')){
	die('-1');
} 
Class Creote_update{
// check updates
}
new Creote_update();
