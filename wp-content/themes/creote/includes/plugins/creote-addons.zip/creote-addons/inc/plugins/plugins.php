<?php
/**
 * Load and register widgets
 *
 * @package Creote
 */
require_once CREOTE_ADDONS_DIR  . '/inc/plugins/header.php';
require_once CREOTE_ADDONS_DIR  . '/inc/plugins/service.php';
require_once CREOTE_ADDONS_DIR  . '/inc/plugins/project.php';
require_once CREOTE_ADDONS_DIR  . '/inc/plugins/footer.php';
require_once CREOTE_ADDONS_DIR  . '/inc/plugins/mega-menu.php';